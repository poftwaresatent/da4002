public class Pair<TT>
{
    public TT one, two;
    public Pair(TT _one, TT _two) {
	one = _one;
	two = _two;
    }
}
