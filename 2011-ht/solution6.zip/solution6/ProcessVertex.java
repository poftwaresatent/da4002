public interface ProcessVertex
{
    public boolean visit(Vertex vertex, int counter);
}
