#ifndef ITADS_EX6_MINI_TOTO_H
#define ITADS_EX6_MINI_TOTO_H

#include "bar.h"

void toto_init (Bar * tab, int len);

#endif /* ITADS_EX6_MINI_TOTO_H */
