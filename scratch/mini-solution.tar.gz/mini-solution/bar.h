#ifndef ITADS_EX6_MINI_BAR_H
#define ITADS_EX6_MINI_BAR_H

typedef struct {
  int num;
  char letter;
} Bar;

void bar_hello (const Bar * bar);

#endif /* ITADS_EX6_MINI_BAR_H */
