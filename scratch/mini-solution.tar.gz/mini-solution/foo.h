#ifndef ITADS_EX6_MINI_FOO_H
#define ITADS_EX6_MINI_FOO_H

void foo_hello (int num, char letter);

#endif /* ITADS_EX6_MINI_FOO_H */
